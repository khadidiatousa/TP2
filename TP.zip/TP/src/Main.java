import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        ArrayList<Personne> personnes = new ArrayList<>(Arrays.asList(
                new Etudiant("sall", "khady", "02/07/2000", "", Classe.L3),
                new Etudiant("diongue", "maty", "11/11/2011", "", Classe.M2),
                new Etudiant("diop", "pape", "29/12/2003", "", Classe.M1),
                new Professeur("diop", "babacar", "02/12/1980", "java"),
                new Professeur("gueye", "abdou", "02/02/1988", "c#"),
                new Professeur("fall", "souley", "30/03/1978", "PHP")
        ));

        for (Personne personne : personnes) {
            System.out.println(personne);
        }
    }
}
