class Personne {
    String nom;
    String prenom;
    String date_naissance;
    String email;

    public Personne(String nom, String prenom, String date_naissance, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.date_naissance = date_naissance;
        this.email = email;
    }

    public String toString() {
        return "Nom: " + nom + ", Prénom: " + prenom + ", Date de naissance: " + date_naissance + ", Email: " + email;
    }
}

class Etudiant extends Personne implements EtudiantInterface {
    String numero_etudiant;
    Classe classe;

    public Etudiant(String nom, String prenom, String date_naissance, String numero_etudiant, Classe classe) {
        super(nom, prenom, date_naissance, "");
        this.numero_etudiant = numero_etudiant;
        this.classe = classe;
    }

    public String toString() {
        return super.toString() + ", Numéro étudiant: " + numero_etudiant + ", Classe: " + classe;
    }

    public void sInscrire() {
        System.out.println(prenom + " " + nom + " s'est inscrit.");
    }

    public void suivreCours() {
        System.out.println(prenom + " " + nom + " suit un cours.");
    }

    public void passerExamen() {
        System.out.println(prenom + " " + nom + " passe un examen.");
    }
}
class Professeur extends Personne implements ProfesseurInterface {
    String specialite;

    public Professeur(String nom, String prenom, String date_naissance, String specialite) {
        super(nom, prenom, date_naissance, "");
        this.specialite = specialite;
    }

    public String toString() {
        return super.toString() + ", Spécialité: " + specialite;
    }

    public void enseigner() {
        System.out.println(prenom + " " + nom + " enseigne.");
    }

    public void corrigerExamen() {
        System.out.println(prenom + " " + nom + " corrige un examen.");
    }
}

interface EtudiantInterface {
    void sInscrire();
    void suivreCours();
    void passerExamen();
}

interface ProfesseurInterface {
    void enseigner();
    void corrigerExamen();
}

enum Classe {
    L3, M1, M2,
}